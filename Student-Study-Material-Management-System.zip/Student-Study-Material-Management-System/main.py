
from flask import Flask,render_template,request,session,redirect,url_for,flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import login_user,logout_user,login_manager,LoginManager
from flask_login import login_required,current_user

local_server= True
app = Flask(__name__)
app.secret_key='harshitha'

login_manager=LoginManager(app)
login_manager.login_view='login'

@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:@localhost/ssmms'
db=SQLAlchemy(app)


class Admin(UserMixin,db.Model):
    AdminId=db.Column(db.Integer,primary_key=True)
    AdminName=db.Column(db.String(100))
    Email=db.Column(db.String(100))
    password=db.Column(db.String(1000))
    
class Student(db.Model):
    StudentId=db.Column(db.String(50),primary_key=True)
    Name=db.Column(db.String(50))
    SEmail=db.Column(db.String(50),unique=True)
    SPassword=db.Column(db.String(1000))
    Role=db.Column(db.String(50))

class Studymaterial(db.Model):
    MId=db.Column(db.Integer,primary_key=True)
    MScheme	=db.Column(db.Integer)
    MDept=db.Column(db.String(50))
    MSem=db.Column(db.Integer)
    MSub=db.Column(db.String(50))
    UploadedFile=db.Column(db.String(300))

class Questionpaper(db.Model):
    PId=db.Column(db.Integer,primary_key=True)
    PScheme	=db.Column(db.Integer)
    PDept=db.Column(db.String(50))
    PSem=db.Column(db.Integer)
    PSub=db.Column(db.String(50))
    UploadedPYQs=db.Column(db.String(300))

class Triggers(db.Model):
    tid=db.Column(db.Integer,primary_key=True)
    StudentId=db.Column(db.String(100))
    Name=db.Column(db.String(100))
    SEmail=db.Column(db.String(100))
    action=db.Column(db.String(100))
    timestamp=db.Column(db.String(100))
   
    
    
@app.route('/')
def index(): 
    return render_template('base.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/student')
def student(): 
    return render_template('student.html')




@app.route('/manages')
def manages():
    return render_template('manages.html')

@app.route('/studentlogin')
def studentlogin(): 
    return render_template('studentlogin.html')

@app.route('/department')
def department(): 
    return render_template('department.html')

@app.route('/login',methods=['POST','GET'])
def login():
    if request.method == "POST":
        Email=request.form.get('email')
        password=request.form.get('password')
        user=Admin.query.filter_by(Email=Email).first()
        if user and  user.password==password:
            session['username'] = user.AdminName
            return redirect(url_for('manages'))
        else:
            flash("invaild credentials","danger")
            return render_template('admin.html')
            
     
    return render_template('admin.html')

@app.route('/student',methods=['POST','GET'])

def addstudent():
     dept=Student.query.all()
     if request.method=="POST":
        StudentId=request.form.get('sid')
        Name=request.form.get('sname')
        SEmail=request.form.get('semail')
        SPassword=request.form.get('spassword')
        Role=request.form.get('role')
        query=Student(StudentId=StudentId,Name=Name, SEmail= SEmail,SPassword=SPassword,Role=Role)
        db.session.add(query)
        db.session.commit()

        flash("Added Successfully","info")
        return redirect('/studentdetails')
     return render_template('studentdetails.html',dept=dept)
    

@app.route('/studentdetails',methods=['POST','GET'])
def studentdetails():
     query=Student.query.all() 
     return render_template('studentdetails.html',query=query)


@app.route("/edit/<string:StudentId>",methods=['POST','GET'])

def edit(StudentId):
    

    if request.method=="POST":
        
        Name=request.form.get('sname')
        SEmail=request.form.get('semail')
        SPassword=request.form.get('spassword')
        Role=request.form.get('role')

        posts=Student.query.filter_by(StudentId=StudentId).first()
        posts.Name=Name
        posts.SEmail=SEmail
        posts.SPassword=SPassword
        posts.Role=Role
        db.session.commit()
        flash("Details is Updated","success")
        return redirect('/studentdetails')
    
    posts=Student.query.filter_by(StudentId=StudentId).first()

    return render_template('update.html',posts=posts)
    
   

@app.route("/delete/<string:StudentId>",methods=['POST','GET'])
def delete(StudentId):
    posts=Student.query.filter_by(StudentId=StudentId).first()
    db.session.delete(posts)
    db.session.commit()
    
    flash("Student Record Deleted Successfully","danger")
    return redirect('/studentdetails')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logout SuccessFul","warning")
    return redirect(url_for('login'))

@app.route('/addsm',methods=['POST','GET'])
def addstudymaterial():
     dept=Studymaterial.query.all()
     if request.method=="POST":
        MId=request.form.get('mid')
        MScheme=request.form.get('msch')
        MDept=request.form.get('mdep')
        MSem=request.form.get('msem')
        MSub=request.form.get('msub')
        UploadedFile=request.form.get('ufile')
        query=Studymaterial(MId=MId, MScheme= MScheme,MDept=MDept,MSem=MSem,MSub=MSub,UploadedFile=UploadedFile)
        db.session.add(query)
        db.session.commit()

        flash("Added Successfully","info")
        return redirect('/manages')
     return render_template('addsm.html',dept=dept)

@app.route('/addpyq',methods=['POST','GET'])
def addquestionpaper():
     dept=Questionpaper.query.all()
     if request.method=="POST":
        PId=request.form.get('pid')
        PScheme=request.form.get('psch')
        PDept=request.form.get('pdep')
        PSem=request.form.get('psem')
        PSub=request.form.get('psub')
        UploadedPYQS=request.form.get('pfile')
        query=Questionpaper(PId=PId, PScheme= PScheme,PDept=PDept,PSem=PSem,PSub=PSub,UploadedPYQs=UploadedPYQS)
        db.session.add(query)
        db.session.commit()

        flash("Added Successfully","info")
        return redirect('/manages')
     return render_template('addpyq.html',dept=dept)
 
@app.route('/signin',methods=['POST','GET'])
def signin():
    if request.method == "POST":
        SEmail=request.form.get('semail')
        SPassword=request.form.get('spassword')
        user=Student.query.filter_by(SEmail=SEmail).first()
        if user and  user.SPassword==SPassword:
            session['username'] = user.Name
            return redirect(url_for('department'))
        else:
            flash("invaild credentials","danger")
            return render_template('studentlogin.html')
            
     
    return render_template('studentlogin.html')

@app.route('/signout')

def signout():
    logout_user()
    flash("Logout SuccessFul","warning")
    return redirect(url_for('studentlogin'))

@app.route('/triggers')
def triggers():
    # query=db.engine.execute(f"SELECT * FROM `trig`") 
    query=Triggers.query.all()
    return render_template('triggers.html',query=query)

@app.route('/ise')
def ise(): 
    return render_template('ise.html')

@app.route('/aiml')
def aiml(): 
    return render_template('aiml.html')

@app.route('/ece')
def ece(): 
    return render_template('ece.html')

@app.route('/eee')
def eee(): 
    return render_template('eee.html')

app.run(debug=True)    